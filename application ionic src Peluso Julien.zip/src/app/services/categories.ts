export class Categories {
    id: number;
    nom: string;
    description: string;
    img: string;
}
