import {Categories} from './categories';

export class Panneaux {
    id: number;
    categorie: Categories;
    img: string;
    nom: string;
    description: string;
}
