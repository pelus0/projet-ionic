export class Questions {
    id: number;
    img: string;
    question: string;
    r1: string;
    r2: string;
    r3: string;
    r4: string;
    correction: string;
}
