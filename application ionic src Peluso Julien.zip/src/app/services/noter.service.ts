import {Injectable, NgModule} from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NoterService {

  constructor() { }
}
