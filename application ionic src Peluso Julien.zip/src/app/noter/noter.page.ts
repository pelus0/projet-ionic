import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-noter',
  templateUrl: './noter.page.html',
  styleUrls: ['./noter.page.scss'],
})
export class NoterPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
